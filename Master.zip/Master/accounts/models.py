from django.contrib.auth.models import AbstractUser
from django.conf import settings
from django.db import models
from django.db import IntegrityError

class CustomUser(AbstractUser):
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customuser_set',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        verbose_name='groups',
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customuser_set',
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions',
    )

class MemberStatus(models.Model):
    name = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    date = models.DateField()

    def __str__(self):
        return self.name

class Labeler(models.Model):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.name

class Dataset(models.Model):
    name = models.CharField(max_length=255)
    labeler = models.ForeignKey(Labeler, on_delete=models.CASCADE)
    date = models.DateField()
    data = models.IntegerField()

    STATUS_CHOICES = (
        ('Finish', 'Finish'),
        ('Reworking', 'Reworking'),
        ('Assign', 'Assign'),
        ('In Progress', 'In Progress'),
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Assign')

    def __str__(self):
        return self.name

class Member(models.Model):
    name = models.CharField(max_length=255)
    country = models.CharField(max_length=255)

    STATUS_CHOICES = (
        ('In Job', 'In Job'),
        ('Online', 'Online'),
        ('Offline', 'Offline'),
        ('Available', 'Available'),
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Available')

    def __str__(self):
        return self.name

class Job(models.Model):
    name = models.CharField(max_length=100)
    image_count = models.IntegerField()
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.CharField(max_length=50)
    image = models.ImageField(upload_to='job_images/', blank=True, null=True)

    def __str__(self):
        return self.name

    @property
    def status_class(self):
        status_classes = {
            'not assign': 'not-assign',
            'in progress': 'in-progress',
            'finish': 'finish',
            'reworking': 'reworking',
            'assign': 'assign',
        }
        return status_classes.get(self.status.lower(), 'unknown')

class Assignment(models.Model):
    name = models.CharField(max_length=255)
    labeler = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Profile(models.Model):
    SEGMENTATION = (
        ('', 'Choose...'),
        ('Semantic', 'Semantic'),
        ('Instance', 'Instance'),  # Corrected spelling
        ('Panoptic', 'Panoptic'),
    )

    SHAPE = (
        ('', 'Choose...'),
        ('Bounding Box', 'Bounding Box'),
        ('Polygon', 'Polygon'),
    )

    id = models.AutoField(primary_key=True)    
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    segmentation_type = models.CharField(max_length=20, choices=SEGMENTATION, default='')
    shape_type = models.CharField(max_length=20, choices=SHAPE, default='')
    colour = models.CharField(max_length=200)
    start_date = models.DateField()
    end_date = models.DateField()
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)

    # def save(self, *args, **kwargs):
    #     if Profile.objects.filter(user=self.user).exists():
    #         raise ValueError("Profile sudah ada untuk pengguna ini")
    #     super().save(*args, **kwargs)

    def create_labelers():
        labelers = ['Andy', 'Adam', 'Joko', 'Abdul', 'Rani', 'Sandy', 'Dian', 'Satro']
        for name in labelers:
            Labeler.objects.get_or_create(name=name)

    def create_datasets():
        labeler_mapping = {
            'Dataset_Kendaraan': 'Andy',
            'Dataset_Pesawat': 'Adam',
            'Dataset_Buah': 'Joko',
            'Dataset_Hewan': 'Abdul',
            'Dataset_Furniture': 'Rani',
            'Dataset_Siswa': 'Dian',
            'Dataset_Layangan': 'Satro',
        }
        status_mapping = ['Finish', 'Reworking', 'Assign', 'In Progress']
        for name, labeler_name in labeler_mapping.items():
            labeler = Labeler.objects.get(name=labeler_name)
            for status in status_mapping:
                Dataset.objects.create(name=name, labeler=labeler, date='2022-04-17', data=130, status=status)

    def create_members():
        members = [
            ('David', 'Italy'),
            ('Amit', 'India'),
        ]
        for name, country in members:
            Member.objects.get_or_create(name=name, country=country, status='In Job')

    # def add_data():
    #     create_labelers()
    #     create_datasets()
    #     create_members()

    # if __name__ == "__main__":
    #     add_data()
