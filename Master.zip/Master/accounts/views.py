from django.shortcuts import render, redirect
from django.contrib.auth import login as auth_login, logout as auth_logout
from django.contrib import messages
from .models import Profile
from django.http import HttpResponse
from .forms import RegisterForm, LoginForm, JobForm
from .models import MemberStatus, Job, Profile, Assignment  # Pastikan model Assignment telah dibuat
from django.db import IntegrityError
from django.core.exceptions import ValidationError

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect('dashboard')  # Redirect ke halaman dashboard setelah registrasi
    else:
        form = RegisterForm()
    return render(request, 'accounts/register.html', {'form': form})

def login(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            return redirect('dashboard')  # Redirect ke halaman dashboard setelah login
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})

def logout(request):
    auth_logout(request)
    return redirect('login')  # Redirect ke halaman login setelah logout

def welcome(request):
    return render(request, 'accounts/dashboard.html')  # Halaman dashboard setelah login

def role(request):
    jobs = [
        {'no': i, 'email': 'Susanoo@gmail.com (0879684736382)', 'project': '0 (All)', 'group': '-'} for i in range(1, 13)
    ]
    return render(request, 'accounts/role.html', {'jobs': jobs})

def dashboard(request):
    member_statuses = MemberStatus.objects.all()
    return render(request, 'accounts/dashboard.html', {'member_statuses': member_statuses})

def job(request):
    jobs = Job.objects.all()
    assignments = Assignment.objects.all()  # Menggunakan model Assignment yang sesuai
    context = {
        'jobs': jobs,
        'assignments': assignments
    }
    return render(request, 'accounts/job.html', context)

# def add_profile(request):
#     if request.method == "POST":
#         # Check if the profile already exists
#         profile, created = Profile.objects.get_or_create(user=request.user, defaults={
#             'title': request.POST.get('title'),
#             'description': request.POST.get('description'),
#             'segmentation': request.POST.get('segmentation'),
#             'shape': request.POST.get('shape'),
#             'colour': request.POST.get('colour'),
#             'start_date': request.POST.get('start_date'),
#             'end_date': request.POST.get('end_date'),
#         })

#         if created:
#             messages.success(request, "Profile successfully created.")
#         else:
#             messages.error(request, "Profile already exists for this user.")
        
#         return redirect('profile_list')  # Or any other appropriate redirect

#     return render(request, "add_profile.html")

def add_profile(request):
    context = None
    if request.method == "POST":
        ProfileForm = ProfileForm(request.POST)        
        if profileForm.is_valid():
            profileForm.save()
            return render(request, 'accounts/job.html', {'profileForm': profileForm})
    else: 
        profileForm = ProfileForm()
        Profile = Profile.objects.all()
        context ={
            'profileForm': profileForm,
            'profiles' : Profile,
        } 
        return render(request, 'accounts/job.html', context)

    # return redirect('/accounts/job')

def profile_list(request):
    profiles = Profile.objects.all()
    return render(request, 'accounts/profile_list.html', {'profiles': profiles})

def profile_detail(request, pk):
    profile = Profile.objects.get(pk=pk)
    return render(request, 'accounts/profile_detail.html', {'profile': profile})

def add_job(request):
    if request.method == "POST":
        jobForm = JobForm(request.POST)
        if jobForm.is_valid():
            jobForm.save()
            return render(request, 'accounts/job.html')


# class Profile(models.Model):
#     user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
#     title = models.CharField(max_length=200)
#     description = models.TextField(blank=True, null=True)
#     segmentation = models.CharField(max_length=200)
#     shape = models.CharField(max_length=200)
#     colour = models.CharField(max_length=200)
#     start_date = models.DateField()
#     end_date = models.DateField()

#     def clean(self):
#         # Check if another profile exists for the same user
#         if Profile.objects.filter(user=self.user).exclude(pk=self.pk).exists():
#             raise ValidationError("Profile sudah ada untuk pengguna ini")

#     def save(self, *args, **kwargs):
#         self.full_clean()  # This will call clean method before saving
#         super().save(*args, **kwargs)