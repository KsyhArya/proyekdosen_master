<?php
require_once "config.php";

// Periksa apakah formulir telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari formulir
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $bio = $_POST["bio"];

    // Query SQL untuk menambahkan profil
    $sql = "INSERT INTO accounts_job (name, email, phone, bio) VALUES ('$name', '$email', '$phone', '$bio')";

    // Jalankan query
    if ($conn->query($sql) === TRUE) {
        echo "Profile berhasil ditambahkan.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();

}
?>