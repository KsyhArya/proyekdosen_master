<?php

require_once "config.php";

$sql = "SELECT * FROM jobs WHERE job_name = 'Job_AnotasilmageKucing'"; // Replace 'Job_AnotasilmageKucing' with the specific job name 

$result = $conn->query($sql);


if ($result->num_rows > 0) { 

  // 4. Output the Profile Details 

  while($row = $result->fetch_assoc()) {

    echo "<div class='job-profile'>";

    echo "<h2>" . $row["job_name"] . "</h2>"; 

    echo "<p>Image: " . $row["image"] . "</p>";

    echo "<p>Date: " . $row["date_start"] . " - " . $row["date_end"] . "</p>";

    echo "<p>Status: " . $row["status"] . "</p>";

    echo "</div>";

  }

} else {

  echo "No profile found.";

}


// 5. Close Connection

$conn->close();


?>