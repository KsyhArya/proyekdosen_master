# accounts/forms.py

from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser, Profile, Job

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2']

class LoginForm(AuthenticationForm):
    username = forms.CharField(label='Username', max_length=254)
    password = forms.CharField(label='Password', widget=forms.PasswordInput)

SEGMENTATION = (
    ('', 'Choose...'),
    ('Semantic', 'Semantic'),
    ('Instance', 'Instance'),
    ('Panoptic', 'Panoptic'),
)
SHAPE = (
    ('', 'Choose...'),
    ('Bounding Box', 'Bounding Box'),
    ('Polygon', 'Polygon'),
)
class ProfileForm(forms.ModelForm):       
    title = forms.CharField(required=False)
    description = forms.CharField(required=False, widget=forms.Textarea)
    segmentation_type = forms.ChoiceField(choices=SEGMENTATION)
    shape_type = forms.ChoiceField(choices=SHAPE)
    colour = forms.CharField(required=False)
    start_date = forms.DateField(required=False, widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    end_date = forms.DateField(required=False, widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    user = forms.CharField(required=False)

    class Meta:
        model = Profile
        fields = ('title', 'description', 'segmentation_type', 'shape_type', 'colour', 'start_date', 'end_date', 'user')
        
class JobForm(forms.ModelForm):

    class Meta:
        model = Job
        fields = ('id', 'name', 'image_count', 'start_date', 'end_date', 'status', 'image')