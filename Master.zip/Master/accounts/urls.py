# accounts/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('dashboard/', views.welcome, name='dashboard'),  # URL untuk halaman baru setelah login
    path('role/', views.role, name='role'),
    path('job/', views.job, name='job'),
    path('add_profile/', views.add_profile, name='add_profile'),
    # path('add-job/', views.add_job, name='add-job'),
]
